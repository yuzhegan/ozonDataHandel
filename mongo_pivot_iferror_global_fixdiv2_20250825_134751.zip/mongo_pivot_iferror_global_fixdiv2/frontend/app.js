(function(){
const $=(s)=>document.querySelector(s);
const apiBaseEl=$("#apiBase"),healthEl=$("#health"),collEl=$("#collection"),limitEl=$("#limit"),skipEl=$("#skip"),filtersEl=$("#filters");
const btnLoad=$("#btnLoad"),btnPeek=$("#btnPeek"),btnExport=$("#btnExportCsv"),rowsBadge=$("#rowsBadge"),logEl=$("#log");
const availableFieldsEl=$("#availableFields"),fieldSearchEl=$("#fieldSearch");
const rowsZone=$("#rowsZone"),colsZone=$("#colsZone"),valsZone=$("#valsZone");
const calcNameEl=$("#calcName"),calcExprEl=$("#calcExpr"),btnAddCalc=$("#btnAddCalc"),computedListEl=$("#computedList");
const pivotContainer=$("#pivotContainer"),formatPanelEl=$("#formatPanel");
const viewModeEl=$("#viewMode"),subtotalToggleEl=$("#subtotalToggle");
const profileNameEl=$("#profileName"),btnSaveCloud=$("#btnSaveCloud"),btnLoadCloud=$("#btnLoadCloud"),btnListCloud=$("#btnListCloud"),cloudListEl=$("#cloudList");
const btnUseConfig=$("#btnUseConfig");
const iferrAllToggle=$("#iferrAllToggle"), iferrFallbackEl=$("#iferrFallback");

let currentCollection="", rawBaseRows=[], currentRows=[];
let hiddenFields=new Set(), computedDefs=[], layout={rows:[],cols:[],vals:[]}, formats={};
let subtotalEnabled=false, viewMode='pivot';
let iferrDefaultEnabled=false, iferrDefaultFallback=0;

function log(s){const t=new Date().toISOString().substr(11,8); logEl.textContent+=`[${t}] ${s}\n`; logEl.scrollTop=logEl.scrollHeight;}

function setApiBaseFromConfig(){ if(window.__APP_CONFIG__?.API_BASE) apiBaseEl.value=window.__APP_CONFIG__.API_BASE; }
function guessApiBases(){ const list=[]; if(window.__APP_CONFIG__?.API_BASE) list.push(window.__APP_CONFIG__.API_BASE); if(apiBaseEl?.value) list.push(apiBaseEl.value); const host=location.hostname||'localhost'; list.push(`http://${host}:7002`,`http://${host}:8000`); return [...new Set(list)]; }
async function smartPingAndInit(){ for(const b of guessApiBases()){ try{ const r=await fetch(`${b}/api/health`); const j=await r.json(); if(j?.status==='ok'){ apiBaseEl.value=b; healthEl.textContent='OK'; healthEl.style.color='#4ade80'; await loadCollections(); if(collEl.options.length){ currentCollection=collEl.value; await doPeek(); } return; } }catch(e){ log('健康检查失败：'+b); } } healthEl.textContent='连接失败'; healthEl.style.color='#f87171';}

async function loadCollections(){ const r=await fetch(`${apiBaseEl.value}/api/collections`); const j=await r.json(); collEl.innerHTML=''; (j.collections||[]).forEach(c=>{ const o=document.createElement('option'); o.value=c; o.textContent=c; collEl.appendChild(o); }); }

btnUseConfig && (btnUseConfig.onclick=()=>{ if(window.__APP_CONFIG__?.API_BASE){ apiBaseEl.value=window.__APP_CONFIG__.API_BASE; smartPingAndInit(); }});

// numeric parser
function num(x){ if(x===null||x===undefined||x==='') return 0; if(typeof x==='number'&&isFinite(x)) return x;
  if(typeof x==='string'){ let s=x.replace(/\u00A0/g,' ').trim().replace(/\s+/g,''); if(s.includes(',')&&s.includes('.')){ if(s.lastIndexOf(',')>s.lastIndexOf('.')){ s=s.replace(/\./g,'').replace(',', '.'); } else { s=s.replace(/,/g,''); } } else if(s.includes(',')){ s=s.replace(/\./g,''); s=s.replace(/,/g,'.'); } const v=parseFloat(s); return isNaN(v)?0:v; }
  const v=Number(x); return isNaN(v)?0:v; }

// compilers with global IFERROR
function compileExpr(expr){
  return function(r){
    try{
      const keys=Object.keys(r).sort((a,b)=>b.length-a.length);
      let code=expr;
      keys.forEach(k=>{ const re=new RegExp(`\\b${k.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&')}\\b`,'g'); code=code.replace(re, `num(r["${k}"])`); });
      const FN=new Function('r','num','__enabled','__fb',`
        const IFERROR=(v,fb=0)=>{ const n=Number(v); return (Number.isFinite(n)&&!Number.isNaN(n))?v:fb; };
        const DIV=(a,b,fb=0)=>{ const q=num(a)/num(b); return (Number.isFinite(q)&&!Number.isNaN(q))?q:fb; };
        const _res = (${code});
        return __enabled ? IFERROR(_res, __fb) : _res;
      `);
      const fb = Number(iferrFallbackEl?.value ?? iferrDefaultFallback) || 0;
      return FN(r,num, !!iferrDefaultEnabled, fb);
    }catch(e){ return null; }
  };
}
function extractVars(expr){ const set=new Set(); const rx=/[A-Za-z_][A-Za-z0-9_]*/g; let m; while((m=rx.exec(expr))){ set.add(m[0]); }
  ['num','Math','Infinity','NaN','undefined','true','false','IFERROR','DIV'].forEach(k=>set.delete(k)); return [...set]; }
function compileAggExpr(expr){
  const vars=extractVars(expr); let code=expr;
  vars.sort((a,b)=>b.length-a.length);
  vars.forEach(v=>{ const re=new RegExp(`\\b${v.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&')}\\b`,'g'); code=code.replace(re, `get("${v}")`); });
  return function(get){
    try{
      const FN=new Function('get','num','__enabled','__fb',`
        const IFERROR=(v,fb=0)=>{ const n=Number(v); return (Number.isFinite(n)&&!Number.isNaN(n))?v:fb; };
        const DIV=(a,b,fb=0)=>{ const q=num(a)/num(b); return (Number.isFinite(q)&&!Number.isNaN(q))?q:fb; };
        const _res = (${code});
        return __enabled ? IFERROR(_res, __fb) : _res;
      `);
      const fb = Number(iferrFallbackEl?.value ?? iferrDefaultFallback) || 0;
      return FN(get,num, !!iferrDefaultEnabled, fb);
    }catch(e){ return null; }
  };
}

function applyComputed(rows){ if(!computedDefs.length) return rows; return rows.map(r=>{ const out={...r}; computedDefs.forEach(def=>{ out[def.name]=def.fn(out); }); return out; }); }
function rebuildAvailableFields(){ availableFieldsEl.innerHTML=''; const sample=currentRows[0]||{}; let fields=Object.keys(sample).filter(k=>!hiddenFields.has(k)); const kw=(fieldSearchEl?.value||'').trim().toLowerCase(); if(kw) fields=fields.filter(x=>x.toLowerCase().includes(kw)); fields.sort(); fields.forEach(f=>{ const chip=document.createElement('div'); chip.className='field'; chip.draggable=true; chip.dataset.field=f; chip.innerHTML=`<span>${f}</span>`; chip.addEventListener('dragstart',onDragStart); availableFieldsEl.appendChild(chip); }); }

function renderZone(zoneEl, arr, showAgg){ zoneEl.innerHTML=''; arr.forEach((item,idx)=>{ const f=typeof item==='string'?item:item.field; const chip=document.createElement('div'); chip.className='field'; chip.draggable=true; chip.dataset.field=f; chip.dataset.zone=zoneEl.id; chip.dataset.index=idx; let inner=`<span>${f}</span>`; if(showAgg){ const agg=item.agg||'sum'; inner+=` <select class='agg'><option value='sum'${agg==='sum'?' selected':''}>sum</option><option value='avg'${agg==='avg'?' selected':''}>avg</option><option value='count'${agg==='count'?' selected':''}>count</option><option value='min'${agg==='min'?' selected':''}>min</option><option value='max'${agg==='max'?' selected':''}>max</option></select>`;} inner+=` <span class='remove'>✕</span>`; chip.innerHTML=inner; chip.addEventListener('dragstart',onDragStart); chip.querySelector('.remove').onclick=()=>{ arr.splice(idx,1); saveState(); renderZones(); renderPivot(); }; if(showAgg){ chip.querySelector('.agg').onchange=e=>{ arr[idx].agg=e.target.value; saveState(); renderPivot(); renderFormatPanel(); }; } zoneEl.appendChild(chip); }); }
function renderZones(){ renderZone(rowsZone,layout.rows,false); renderZone(colsZone,layout.cols,false); renderZone(valsZone,layout.vals,true); renderFormatPanel(); }
function onDragStart(e){ const field=e.currentTarget.dataset.field; const zone=e.currentTarget.dataset.zone||'available'; const index=e.currentTarget.dataset.index; e.dataTransfer.setData('text/plain', JSON.stringify({field,from:zone,index:index?Number(index):null})); }
[rowsZone,colsZone,valsZone,availableFieldsEl,computedListEl].forEach(el=>{ el.addEventListener('dragover',e=>e.preventDefault()); el.addEventListener('drop', e=>{ e.preventDefault(); const data=JSON.parse(e.dataTransfer.getData('text/plain')); const to=el.id; if(data.from==='rowsZone') layout.rows.splice(data.index,1); if(data.from==='colsZone') layout.cols.splice(data.index,1); if(data.from==='valsZone') layout.vals.splice(data.index,1); if(to==='rowsZone') layout.rows.push(data.field); else if(to==='colsZone') layout.cols.push(data.field); else if(to==='valsZone') layout.vals.push({field:data.field,agg:'sum'}); saveState(); renderZones(); renderPivot(); }); });

function metricKey(vd){ return `${vd.field}|${vd.agg||'sum'}`; }
function renderFormatPanel(){ formatPanelEl.innerHTML=''; const list=layout.vals.length?layout.vals:[]; list.forEach(vd=>{ const key=metricKey(vd); const cfgRaw=formats[key]||{}; const cfg={decimals:Number.isFinite(cfgRaw.decimals)?cfgRaw.decimals:2, thousand:cfgRaw.thousand!==undefined?!!cfgRaw.thousand:true, currency:cfgRaw.currency||'', currencyPos:cfgRaw.currencyPos||'prefix'}; const card=document.createElement('div'); card.className='metric-card'; card.innerHTML=`<div class='metric-title'>${vd.field} ${vd.agg||'sum'}</div><div class='metric-grid'><label>小数位<input type='number' class='fmt-dec' min='0' max='8' step='1' value='${cfg.decimals}'/></label><label>千分位<input type='checkbox' class='fmt-th' ${cfg.thousand?'checked':''}/></label><label>货币符号<input type='text' class='fmt-cur' value='${cfg.currency.replace(/\"/g,'&quot;')}'/></label><label>位置<select class='fmt-pos'><option value='prefix'${cfg.currencyPos==='prefix'?' selected':''}>前</option><option value='suffix'${cfg.currencyPos==='suffix'?' selected':''}>后</option></select></label></div>`; const dec=card.querySelector('.fmt-dec'),th=card.querySelector('.fmt-th'),cur=card.querySelector('.fmt-cur'),pos=card.querySelector('.fmt-pos'); dec.oninput=e=>{ const v=Number(e.target.value); cfg.decimals=Number.isFinite(v)?Math.max(0,Math.min(8,v)):0; formats[key]=cfg; saveState(); renderPivot(); }; th.onchange=e=>{ cfg.thousand=!!e.target.checked; formats[key]=cfg; saveState(); renderPivot(); }; cur.oninput=e=>{ cfg.currency=e.target.value; formats[key]=cfg; saveState(); renderPivot(); }; pos.onchange=e=>{ cfg.currencyPos=e.target.value; formats[key]=cfg; saveState(); renderPivot(); }; formatPanelEl.appendChild(card); }); if(!list.length){ const p=document.createElement('div'); p.className='small'; p.textContent='将指标拖入“指标（聚合）”后，在此配置格式。'; formatPanelEl.appendChild(p); } }
function formatNumber(n,opt){ const decimals=Number(opt?.decimals??2); const thousand=!!opt?.thousand; const currency=opt?.currency||''; const pos=opt?.currencyPos||'prefix'; const fixed=(Math.round(n*(10**decimals))/(10**decimals)).toFixed(decimals); let x=fixed; if(thousand){ const [i,d]=fixed.split('.'); const sep=i.replace(/\B(?=(\d{3})+(?!\d))/g,','); x=d!==undefined?`${sep}.${d}`:sep; } return currency? (pos==='suffix'?`${x}${currency}`:`${currency}${x}`):x; }
function formatAgg(value,agg,fmt){ const n=(typeof value==='number')?value:num(value); if(!isFinite(n)) return ''; if(agg==='count') return String(Math.round(n)); return formatNumber(n,fmt); }

function saveState(){ localStorage.setItem(`pivot_hidden_${currentCollection}`, JSON.stringify([...hiddenFields])); localStorage.setItem(`pivot_layout_${currentCollection}`, JSON.stringify(layout)); localStorage.setItem(`pivot_formulas_${currentCollection}`, JSON.stringify(computedDefs.map(({name,expr})=>({name,expr})))); localStorage.setItem(`pivot_formats_${currentCollection}`, JSON.stringify(formats)); localStorage.setItem(`pivot_subtotal_${currentCollection}`, JSON.stringify(subtotalEnabled)); localStorage.setItem(`pivot_view_${currentCollection}`, viewMode); localStorage.setItem(`pivot_iferr_enabled_${currentCollection}`, JSON.stringify(iferrDefaultEnabled)); localStorage.setItem(`pivot_iferr_fb_${currentCollection}`, JSON.stringify(Number(iferrFallbackEl?.value ?? iferrDefaultFallback)||0)); }
function loadState(){ hiddenFields=new Set(JSON.parse(localStorage.getItem(`pivot_hidden_${currentCollection}`)||'[]')); layout=JSON.parse(localStorage.getItem(`pivot_layout_${currentCollection}`)||'{"rows":[],"cols":[],"vals":[]}')||{rows:[],cols:[],vals:[]}; const f=JSON.parse(localStorage.getItem(`pivot_formulas_${currentCollection}`)||'[]'); computedDefs=f.map(x=>({...x, fn:compileExpr(x.expr), fnAgg:compileAggExpr(x.expr)})); formats=JSON.parse(localStorage.getItem(`pivot_formats_${currentCollection}`)||'{}'); subtotalEnabled=JSON.parse(localStorage.getItem(`pivot_subtotal_${currentCollection}`)||'false'); viewMode=localStorage.getItem(`pivot_view_${currentCollection}`)||'pivot'; iferrDefaultEnabled=JSON.parse(localStorage.getItem(`pivot_iferr_enabled_${currentCollection}`)||'false'); iferrDefaultFallback=JSON.parse(localStorage.getItem(`pivot_iferr_fb_${currentCollection}`)||'0'); if(iferrAllToggle){ iferrAllToggle.checked=!!iferrDefaultEnabled; } if(iferrFallbackEl){ iferrFallbackEl.value=String(iferrDefaultFallback); } }

function getColumns(){ return Object.keys(rawBaseRows[0]||{}); }

function pivotData(baseRows){
  const rowFields=layout.rows, colFields=layout.cols, valDefs=layout.vals.length?layout.vals:[{field:getColumns()[0]||'',agg:'count'}];
  const sep='\\u0001';
  const computedNames=new Set(computedDefs.map(d=>d.name));
  const computedMap=Object.fromEntries(computedDefs.map(d=>[d.name,d]));

  const rowKey=r=>rowFields.map(f=>String(r[f]??'')).join(sep);
  const colKey=r=>colFields.map(f=>String(r[f]??'')).join(sep);

  const rowKeys=[], colKeys=[], rowSet=new Set(), colSet=new Set();
  baseRows.forEach(r=>{ const rk=rowKey(r), ck=colKey(r); if(!rowSet.has(rk)){rowSet.add(rk);rowKeys.push(rk);} if(!colSet.has(ck)){colSet.add(ck);colKeys.push(ck);} });

  function initAgg(){return {sum:0,count:0,min:Infinity,max:-Infinity}}
  function updateAgg(a,v){const n=num(v); a.sum+=n; a.count++; if(n<a.min)a.min=n; if(n>a.max)a.max=n;}
  function valueAgg(a,t){ if(t==='sum')return a.sum; if(t==='count')return a.count; if(t==='min')return a.min===Infinity?0:a.min; if(t==='max')return a.max===-Infinity?0:a.max; if(t==='avg')return a.count?a.sum/a.count:0; return 0; }

  const map=new Map();
  baseRows.forEach(r0=>{
    const r = {...r0};
    computedDefs.forEach(def=>{ r[def.name] = def.fn(r); });
    const rk=rowKey(r), ck=colKey(r), key=rk+'|'+ck;
    if(!map.has(key)) map.set(key,{});
    const bucket=map.get(key);
    Object.keys(r).forEach(k=>{ if(!bucket[k]) bucket[k]=initAgg(); });
    Object.keys(r).forEach(k=> updateAgg(bucket[k], r[k]));
  });

  const colLabels=colKeys.map(ck=> ck?ck.split(sep):Array(colFields.length).fill(''));
  const headerRows=[];
  for(let level=0; level<colFields.length; level++){ const row=Array(rowFields.length).fill(''); colLabels.forEach(labels=> row.push(labels[level]||'')); headerRows.push(row); }
  const valHeader=Array(rowFields.length).fill(''); colKeys.forEach(_=>{ valDefs.forEach(vd=> valHeader.push(`${vd.field} ${vd.agg}`)); }); headerRows.push(valHeader);
  const colAggTypes=[]; colKeys.forEach(_=>{ valDefs.forEach(vd=> colAggTypes.push(vd.agg)); });

  const dataRows=[];
  rowKeys.forEach(rk=>{
    const rLabel = rk ? rk.split(sep) : Array(rowFields.length).fill('');
    const base=[...rLabel];
    colKeys.forEach(ck=>{
      const bucket = map.get(rk+'|'+ck) || {};
      valDefs.forEach(vd=>{
        let val=0;
        if (computedNames.has(vd.field)){
          const def = computedMap[vd.field];
          const accessor = (name)=>{ const a=bucket[name] || initAgg(); return valueAgg(a,'sum'); };
          val = def.fnAgg ? def.fnAgg(accessor) : 0;
        } else {
          const a=bucket[vd.field] || initAgg();
          val = valueAgg(a, vd.agg);
        }
        base.push(val);
      });
    });
    dataRows.push(base.slice());
  });

  return {headerRows, dataRows, rowFields, colFields, valDefs, colAggTypes, colKeys, rows: baseRows};
}

function renderRawTable(rows){ const headers=Object.keys(rows[0]||{}); const table=document.createElement('table'); const thead=document.createElement('thead'); const trh=document.createElement('tr'); headers.forEach(h=>{ const th=document.createElement('th'); th.textContent=h; trh.appendChild(th); }); thead.appendChild(trh); table.appendChild(thead); const tbody=document.createElement('tbody'); rows.forEach(r=>{ const tr=document.createElement('tr'); headers.forEach(h=>{ const td=document.createElement('td'); td.textContent=String(r[h]??''); tr.appendChild(td); }); tbody.appendChild(tr); }); table.appendChild(tbody); pivotContainer.innerHTML=''; pivotContainer.appendChild(table); btnExport.disabled=false; }

function renderPivot(){
  const base=rawBaseRows;
  if(!base.length){ pivotContainer.innerHTML='<div class="small">没有数据</div>'; rowsBadge.textContent='Rows: 0'; btnExport.disabled=true; return; }
  currentRows = applyComputed(base);
  rebuildAvailableFields(); renderZones(); rowsBadge.textContent=`Rows: ${currentRows.length}`;
  if(viewMode==='raw') return renderRawTable(currentRows);

  const {headerRows, dataRows, rowFields, colFields, valDefs, colAggTypes, colKeys, rows} = pivotData(base);

  // Subtotals include computed contributions
  const thead=document.createElement('thead');
  headerRows.forEach((hr, idx)=>{ const tr=document.createElement('tr'); hr.forEach((cell, ci)=>{ const th=document.createElement('th'); th.textContent = idx<headerRows.length-1 ? (ci<rowFields.length ? (rowFields[ci]||'') : String(cell)) : String(cell); tr.appendChild(th); }); thead.appendChild(tr); });
  const tbody=document.createElement('tbody');

  let rowsToRender=dataRows;
  const applySub=subtotalEnabled && rowFields.length>0 && dataRows.length>0;
  if(applySub){
    const sep='\\u0001';
    const rowPrefixMatch=(r, level, labels)=>{ for(let i=0;i<level;i++){ if(String(r[rowFields[i]]??'')!==String(labels[i]??'')) return false; } return true; };
    const computeTotals=(level, labels)=>{
      const totals=[];
      colKeys.forEach(ck=>{
        valDefs.forEach(vd=>{
          const sameCol=(r)=> colFields.map(f=>String(r[f]??'')).join(sep)===ck;
          if (computedDefs.map(d=>d.name).includes(vd.field)){
            let sums={};
            rows.forEach(r0=>{
              if(sameCol(r0) && rowPrefixMatch(r0, level, labels)){
                const rr={...r0};
                computedDefs.forEach(def=>{ rr[def.name] = def.fn(rr); });
                Object.keys(rr).forEach(k=>{ const v=num(rr[k]); sums[k]=(sums[k]||0)+(isFinite(v)?v:0); });
              }
            });
            const def=computedDefs.find(d=>d.name===vd.field);
            const accessor=(name)=>sums[name]||0;
            totals.push(def.fnAgg ? def.fnAgg(accessor) : 0);
          } else {
            let sum=0,count=0,min=Infinity,max=-Infinity;
            rows.forEach(r0=>{
              if(sameCol(r0) && rowPrefixMatch(r0, level, labels)){
                const n=num(r0[vd.field]); sum+=n; count++; if(n<min)min=n; if(n>max)max=n;
              }
            });
            let v=0;
            if(vd.agg==='sum')v=sum; else if(vd.agg==='count')v=count; else if(vd.agg==='min')v=(min===Infinity?0:min); else if(vd.agg==='max')v=(max===-Infinity?0:max); else if(vd.agg==='avg')v=(count?sum/count:0);
            totals.push(v);
          }
        });
      });
      return totals;
    };
    const final=[];
    for(let i=0;i<dataRows.length;i++){
      const row=dataRows[i]; final.push(row);
      const next=dataRows[i+1];
      const labels=row.slice(0,rowFields.length); const nextLabels=next? next.slice(0,rowFields.length):null;
      let changeLevel=-1;
      if(!nextLabels){ changeLevel=rowFields.length; }
      else { for(let l=0;l<rowFields.length;l++){ if(String(labels[l]||'')!==String(nextLabels[l]||'')){ changeLevel=l+1; break; } } if(changeLevel===-1) changeLevel=0; }
      if(changeLevel>0){
        for(let l=rowFields.length; l>=changeLevel; l--){
          const prefix=labels.slice(0,l); const totals=computeTotals(l, prefix);
          const subtotalRow=Array(rowFields.length).fill(''); if(l>0) subtotalRow[l-1]=`${prefix[l-1]} 小计`; final.push(subtotalRow.concat(totals));
        }
      }
    }
    rowsToRender=final;
  }

  rowsToRender.forEach(r=>{
    const tr=document.createElement('tr');
    r.forEach((cell, ci)=>{
      const td=document.createElement('td');
      if(ci<rowFields.length){ td.textContent=String(cell); }
      else {
        const idx=ci-rowFields.length;
        const aggType=colAggTypes? colAggTypes[idx % colAggTypes.length] : 'sum';
        const vd=valDefs[idx % valDefs.length];
        const key=`${vd.field}|${vd.agg||'sum'}`;
        const fmt=formats[key]||{decimals:2,thousand:true,currency:'',currencyPos:'prefix'};
        td.textContent = formatAgg(cell, aggType, fmt);
      }
      if(String(r[0]).includes('小计')) td.classList.add('total');
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });

  const table=document.createElement('table'); table.appendChild(thead); table.appendChild(tbody);
  pivotContainer.innerHTML=''; pivotContainer.appendChild(table); btnExport.disabled=false;
}

btnExport.onclick=()=>{ const t=pivotContainer.querySelector('table'); if(!t) return; const rows=[]; t.querySelectorAll('tr').forEach(tr=>{ rows.push([...tr.children].map(td=>`"${String(td.textContent).replace(/"/g,'""')}"`).join(',')); }); const csv=rows.join('\\n'); const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=`pivot_${new Date().toISOString().replace(/[:.]/g,'-')}.csv`; document.body.appendChild(a); a.click(); setTimeout(()=>{document.body.removeChild(a); URL.revokeObjectURL(url);},0); };

function tryParseJSON(s){ if(!s) return {}; try{ return JSON.parse(s); }catch{ return {}; } }
function makeBody(){ return {collection: collEl.value, filters: tryParseJSON(filtersEl.value), limit: Number(limitEl.value||5000), skip: Number(skipEl.value||0), projection: {"_id":0}}; }
async function postQuery(body){ const r=await fetch(`${apiBaseEl.value}/api/query`,{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)}); const j=await r.json(); return j.rows||[]; }

btnLoad.onclick=async ()=>{ const body=makeBody(); currentCollection=body.collection; loadState(); rawBaseRows=await postQuery(body); renderPivot(); btnSaveCloud.disabled=false; btnLoadCloud.disabled=false; btnListCloud.disabled=false; };
async function doPeek(){ const url=`${apiBaseEl.value}/api/peek?collection=${encodeURIComponent(collEl.value)}`; currentCollection=collEl.value; loadState(); const r=await fetch(url); const j=await r.json(); rawBaseRows=j.rows||[]; renderPivot(); btnSaveCloud.disabled=false; btnLoadCloud.disabled=false; btnListCloud.disabled=false; }
btnPeek.onclick=doPeek;

btnAddCalc.onclick=()=>{ const name=(calcNameEl.value||'').trim(); const expr=(calcExprEl.value||'').trim(); if(!name||!expr) return; const fn=compileExpr(expr); const fnAgg=compileAggExpr(expr); computedDefs=computedDefs.filter(d=>d.name!==name); computedDefs.push({name,expr,fn,fnAgg}); calcNameEl.value=''; calcExprEl.value=''; renderComputedList(); renderPivot(); saveState(); };
function renderComputedList(){ computedListEl.innerHTML=''; computedDefs.forEach((d,i)=>{ const w=document.createElement('div'); w.className='field'; w.draggable=true; w.dataset.field=d.name; w.innerHTML=`<b>${d.name}</b> = <code>${d.expr}</code> <span class='remove'>✕</span>`; w.addEventListener('dragstart',onDragStart); w.querySelector('.remove').onclick=()=>{ computedDefs.splice(i,1); renderComputedList(); renderPivot(); saveState(); }; computedListEl.appendChild(w); }); }

btnSaveCloud.disabled=true; btnLoadCloud.disabled=true; btnListCloud.disabled=true;
viewModeEl.onchange=()=>{ viewMode=viewModeEl.value; saveState(); renderPivot(); };
subtotalToggleEl.onchange=()=>{ subtotalEnabled=!!subtotalToggleEl.checked; saveState(); renderPivot(); };

iferrAllToggle && (iferrAllToggle.onchange=()=>{ iferrDefaultEnabled=!!iferrAllToggle.checked; saveState(); renderPivot(); });
iferrFallbackEl && (iferrFallbackEl.oninput=()=>{ saveState(); renderPivot(); });

btnSaveCloud.onclick=async ()=>{ if(!currentCollection) return; const name=(profileNameEl.value||'').trim(); if(!name) return; const body={collection: currentCollection, name, layout, hiddenFields:[...hiddenFields], formulas: computedDefs.map(({name,expr})=>({name,expr})), formats, subtotalEnabled, viewMode, iferrorAllEnabled: !!iferrDefaultEnabled, iferrorFallback: Number(iferrFallbackEl?.value ?? 0) || 0 }; const r=await fetch(`${apiBaseEl.value}/api/prefs/save`,{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)}); const j=await r.json(); log('save cloud: '+JSON.stringify(j)); };
btnLoadCloud.onclick=async ()=>{ if(!currentCollection) return; const name=(profileNameEl.value||'').trim(); if(!name) return; const url=`${apiBaseEl.value}/api/prefs/get?collection=${encodeURIComponent(currentCollection)}&name=${encodeURIComponent(name)}`; const r=await fetch(url); const j=await r.json(); if(j && j.doc){ const d=j.doc; layout=d.layout||layout; hiddenFields=new Set(d.hiddenFields||[]); computedDefs=(d.formulas||[]).map(x=>({...x, fn:compileExpr(x.expr), fnAgg:compileAggExpr(x.expr)})); formats=d.formats||{}; subtotalEnabled=!!d.subtotalEnabled; viewMode=d.viewMode||'pivot'; iferrDefaultEnabled=!!d.iferrorAllEnabled; iferrDefaultFallback=Number(d.iferrorFallback||0); if(iferrAllToggle) iferrAllToggle.checked=!!iferrDefaultEnabled; if(iferrFallbackEl) iferrFallbackEl.value=String(iferrDefaultFallback); renderComputedList(); rebuildAvailableFields(); renderZones(); viewModeEl.value=viewMode; subtotalToggleEl.checked=subtotalEnabled; renderPivot(); saveState(); } };

(function(){ setApiBaseFromConfig(); smartPingAndInit().then(()=> log('前端初始化完成（IFERROR 全局兜底 • 修复 DIV v2）')); })();
})();