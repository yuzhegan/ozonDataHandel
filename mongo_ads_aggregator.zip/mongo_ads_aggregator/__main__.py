from .aggregator import _cli
if __name__ == "__main__":
    _cli()
