from __future__ import annotations
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass
class OzonConfig:
    base_url: str = os.getenv("OZON_BASE_URL", "https://api-performance.ozon.ru")
    client_id: str = "82021481-1755918620104@advertising.performance.ozon.ru"
    client_secret: str ="bRUe7Q4Bh6DpiaIaj5HQgBFGHlPEzRsA6pTWEBAm-11qFysh2uG2JQSnJmzHR-Ei5W3VqfS8gy9nYhYlrQ"
    # HTTP
    timeout: int = int(os.getenv("HTTP_TIMEOUT", "30"))
    # 发送 client-id 头（多数端点需要）
    client_id_header: str = "82021481-1755918620104@advertising.performance.ozon.ru"

@dataclass
class MongoConfig:
    uri: str = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    db: str = os.getenv("MONGO_DB", "ozondatas")
    coll: str = os.getenv("MONGO_COLL", "mbcampagin")
