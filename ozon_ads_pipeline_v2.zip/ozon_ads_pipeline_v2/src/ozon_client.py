from __future__ import annotations
import time, re, requests
from typing import Any, Dict, List, Optional
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from .config import OzonConfig

UUID_RE = re.compile(r'^[0-9a-fA-F-]{36}$')

class OzonClient:
    def __init__(self, cfg: OzonConfig):
        self.cfg = cfg
        assert self.cfg.client_id and self.cfg.client_secret, "缺少 OZON_CLIENT_ID / OZON_CLIENT_SECRET"
        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "ozon-performance-client/0.2",
            "client-id": self.cfg.client_id_header or self.cfg.client_id,
        })
        self.access_token: Optional[str] = None
        self.token_type: str = "Bearer"
        self.expires_at: Optional[float] = None
        self._fetch_token()

    def _fetch_token(self) -> None:
        url = self.cfg.base_url.rstrip('/') + "/api/client/token"
        payload = {
            "client_id": self.cfg.client_id,
            "client_secret": self.cfg.client_secret,
            "grant_type": "client_credentials",
        }
        r = requests.post(url, json=payload, timeout=self.cfg.timeout)
        r.raise_for_status()
        data = r.json()
        token = data.get("access_token")
        if not token:
            raise RuntimeError(f"未获取到 access_token: {data}")
        self.token_type = data.get("token_type", "Bearer")
        self.access_token = token
        self.session.headers["Authorization"] = f"{self.token_type} {self.access_token}"
        expires_in = data.get("expires_in")
        self.expires_at = (time.time() + float(expires_in) - 30) if isinstance(expires_in, (int, float)) else None

    def _ensure_token(self):
        if self.expires_at and time.time() >= self.expires_at:
            self._fetch_token()

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=6),
           retry=retry_if_exception_type(requests.RequestException))
    def _get(self, path: str, params: Dict[str, Any] | None = None) -> Dict[str, Any]:
        self._ensure_token()
        url = self.cfg.base_url.rstrip('/') + path
        resp = self.session.get(url, params=params, timeout=self.cfg.timeout)
        if resp.status_code == 401:
            self._fetch_token()
            resp = self.session.get(url, params=params, timeout=self.cfg.timeout)
        resp.raise_for_status()
        return resp.json()

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=6),
           retry=retry_if_exception_type(requests.RequestException))
    def _post(self, path: str, json_data: Dict[str, Any] | None = None) -> Dict[str, Any]:
        self._ensure_token()
        url = self.cfg.base_url.rstrip('/') + path
        resp = self.session.post(url, json=json_data, timeout=self.cfg.timeout)
        if resp.status_code == 401:
            self._fetch_token()
            resp = self.session.post(url, json=json_data, timeout=self.cfg.timeout)
        resp.raise_for_status()
        return resp.json()

    def campaigns(self) -> List[Dict[str, Any]]:
        data = self._get("/api/client/campaign")
        if isinstance(data, dict) and isinstance(data.get("list"), list):
            return data["list"]
        if isinstance(data, list):
            return data
        raise RuntimeError(f"未知的 campaigns 响应结构: {data}")

    def request_statistics_json(self, campaign_ids: List[str], date_from: str, date_to: str, group_by: str = "DATE") -> List[str]:
        payload = {"campaigns": [str(c) for c in campaign_ids], "dateFrom": date_from, "dateTo": date_to, "groupBy": group_by}
        data = self._post("/api/client/statistics/json", json_data=payload)
        uuids: List[str] = []

        def walk(o):
            if isinstance(o, dict):
                for vv in o.values():
                    yield from walk(vv)
            elif isinstance(o, list):
                for vv in o:
                    yield from walk(vv)
            elif isinstance(o, str) and UUID_RE.match(o):
                yield o

        uuids = list(dict.fromkeys(walk(data)))
        if not uuids:
            raise RuntimeError(f"未能解析出 UUID：{data}")
        return uuids

    def report_status(self, uuid: str) -> Dict[str, Any]:
        return self._get(f"/api/client/statistics/{uuid}")

    def download_report(self, uuid: str) -> Dict[str, Any]:
        return self._get("/api/client/statistics/report", params={"UUID": uuid})
