# Ozon Performance Ads 全流程 → MongoDB（mbcampagin）

**功能点：**
1. 使用 `client_id + client_secret` 通过 `/api/client/token` 换取 `access_token`
2. 将 `Authorization: Bearer <access_token>` 自动加入 **所有后续请求** 头（遇 401 自动刷新重试）
3. 获取广告活动列表 → 按状态筛选（可选）
4. 申请日报（返回 UUID）→ 轮询 UUID 状态（成功后）→ 下载报告
5. 若报告缺少日期字段：按 `date_from..date_to` **均匀切分补齐日期**
6. 报表与活动元数据按 `campaignId` **合并**
7. 幂等写入 MongoDB（集合名默认：`mbcampagin`，可通过环境变量覆盖）

> 注：本项目不使用任何手写 `api-key`，全部请求统一走 `Authorization: Bearer <token>`。

---

## 快速开始

1) 安装依赖
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

2) 配置环境变量（可创建 `.env` 文件）：
```env
# Ozon Performance API
OZON_CLIENT_ID=57831202-1741573215907@advertising.performance.ozon.ru
OZON_CLIENT_SECRET=xxxxxxxxxxxxxxxxxxxx

# MongoDB
MONGO_URI=mongodb://localhost:27017
MONGO_DB=ozonads
MONGO_COLL=mbcampagin
```

3) 运行（示例：2025-08-20 至 2025-08-21，仅保留运行中的活动）
```bash
python main.py --date-from 2025-08-20 --date-to 2025-08-21   --states CAMPAIGN_STATE_RUNNING
```

4) 可选：只拉指定活动 ID
```bash
python main.py --date-from 2025-08-20 --date-to 2025-08-21   --campaign-ids 16734360 16774892
```
