from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from models import QueryRequest
from db import list_collections, get_collection, sample_fields
from utils import flatten_doc
from prefs import PrefsStore
import pandas as pd
from io import BytesIO

app=FastAPI(title="Mongo Pivot API (IFERROR Global • Fix DIV v3 + Upload • repack)")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_headers=["*"],allow_methods=["*"])
prefs=PrefsStore()

@app.get("/")
def root(): return {"message":"ok"}

@app.get("/api/health")
def health(): return {"status":"ok"}

@app.get("/api/collections")
def collections(): return {"collections": list_collections()}

@app.get("/api/fields")
def fields(collection:str, sample:int=200): 
    return {"collection":collection,"fields": sample_fields(collection,sample)}

@app.get("/api/peek")
def peek(collection:str, limit:int=50):
    coll=get_collection(collection)
    rows=[flatten_doc(x) for x in coll.find({}, {"_id":0}).limit(limit)]
    return {"count":len(rows),"rows":rows}

@app.post("/api/query")
def query(req: QueryRequest):
    coll=get_collection(req.collection)
    if not isinstance(req.filters, dict):
        raise HTTPException(400, "filters must be object")
    cur=coll.find(req.filters, req.projection).skip(req.skip).limit(req.limit)
    rows=[flatten_doc({k:(str(v) if k=="_id" else v) for k,v in doc.items()}) for doc in cur]
    return {"count":len(rows),"rows":rows}

@app.post("/api/upload")
async def upload(file: UploadFile = File(...), sheet: str | None = Form(None), start_row: int = Form(1)):
    name=file.filename or "upload"
    content=await file.read()
    ext=(name.split(".")[-1] or "").lower()
    rows=[]
    try:
        if ext in ("csv","tsv","txt"):
            sep=","
            if ext=="tsv": sep="\t"
            df=pd.read_csv(BytesIO(content), sep=sep, header=0, skiprows=max(0,start_row-1))
        else:
            sheet_arg=None
            if sheet:
                try:
                    sheet_arg=int(sheet)
                except:
                    sheet_arg=sheet
            df=pd.read_excel(BytesIO(content), sheet_name=sheet_arg, header=0, engine=None)
            if isinstance(df, dict):
                first_key=list(df.keys())[0]
                df=df[first_key]
            if start_row>1:
                df=pd.read_excel(BytesIO(content), sheet_name=sheet_arg, header=start_row-1, engine=None)
        df=df.where(pd.notnull(df), None)
        rows=[{str(k): v for k,v in rec.items()} for rec in df.to_dict(orient="records")]
        fields={c: str(df[c].dtype) for c in df.columns}
        return {"filename": name, "count": len(rows), "rows": rows, "fields": fields}
    except Exception as e:
        raise HTTPException(400, f"Failed to parse file: {e}")
    
@app.get("/api/prefs/list")
def prefs_list(collection:str): return {"items": prefs.list(collection)}

@app.get("/api/prefs/get")
def prefs_get(collection:str, name:str): return {"doc": prefs.get(collection,name)}

@app.post("/api/prefs/save")
def prefs_save(body:dict): return {"ok": prefs.save(body)}

@app.delete("/api/prefs/delete")
def prefs_del(collection:str, name:str): return {"ok": prefs.delete(collection,name)}
