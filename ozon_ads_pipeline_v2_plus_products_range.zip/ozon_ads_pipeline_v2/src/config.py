from __future__ import annotations
import os
from dataclasses import dataclass
from dotenv import load_dotenv
load_dotenv()
@dataclass
class OzonConfig:
    base_url: str = os.getenv("OZON_BASE_URL", "https://api-performance.ozon.ru")
    client_id: str | None = os.getenv("OZON_CLIENT_ID")
    client_secret: str | None = os.getenv("OZON_CLIENT_SECRET")
    timeout: int = int(os.getenv("HTTP_TIMEOUT", "30"))
    client_id_header: str | None = os.getenv("OZON_CLIENT_ID_HEADER", os.getenv("OZON_CLIENT_ID"))
@dataclass
class MongoConfig:
    uri: str = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    db: str = os.getenv("MONGO_DB", "ozonads")
    coll: str = os.getenv("MONGO_COLL", "mbcampagin")
