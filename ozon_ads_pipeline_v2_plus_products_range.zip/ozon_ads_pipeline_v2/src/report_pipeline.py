from __future__ import annotations
from typing import Any, Dict, List, Optional
from icecream import ic
from .config import OzonConfig, MongoConfig
from .ozon_client import OzonClient
from .utils import parse_number
from .mongo_utils import upsert_docs
import time
SUCCESS_STATES = {"SUCCESS", "READY", "DONE"}
def wait_until_ready(client: OzonClient, uuid: str, timeout_sec: int = 180, poll: float = 2.0) -> Dict[str, Any]:
    deadline = time.time() + timeout_sec; last = {}
    while time.time() < deadline:
        st = client.report_status(uuid); last = st
        state = (st.get("state") or st.get("Status") or st.get("status") or "").upper()
        if state in SUCCESS_STATES: return st
        if "ERROR" in state or "FAIL" in state: raise RuntimeError(f"UUID {uuid} 生成失败: {st}")
        time.sleep(poll)
    raise TimeoutError(f"等待 UUID {uuid} 超时，最后状态: {last}")
