from __future__ import annotations
print("This is a minimal placeholder for v2 base.")