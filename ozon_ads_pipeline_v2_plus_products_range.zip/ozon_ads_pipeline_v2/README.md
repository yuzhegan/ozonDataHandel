# Ozon Performance Ads 全流程 → MongoDB（mbcampagin）
(略)

### 批量按日期范围运行（新功能）
```bash
python main_products_range.py --date-from 2025-08-01 --date-to 2025-08-07
```
可选参数：
- `--delay-seconds 1.0`：每天之间暂停 1 秒
- `--stop-on-error`：遇到错误立即终止
